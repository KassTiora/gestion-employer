import React from "react";
import logo from "./logo.png";
import {Link} from "react-router-dom"

const Navbar = () => {
  return (
    <div style={{background:"#1255A5"}}>
      <Link to="/register">
          <img src={logo} style={{height:"36px", width:"350px"}} className="content-center" alt="logo" />
      </Link>
    </div>
  );
};

export default Navbar;
